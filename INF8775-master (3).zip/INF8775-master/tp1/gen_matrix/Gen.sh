#!/bin/bash
for N in {min..max}; do
  for I in {1..5}; do
    ./Gen $N "ex_"$N"."$I
  done
done
