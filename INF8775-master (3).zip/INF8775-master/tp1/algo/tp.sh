python tp.py $@
